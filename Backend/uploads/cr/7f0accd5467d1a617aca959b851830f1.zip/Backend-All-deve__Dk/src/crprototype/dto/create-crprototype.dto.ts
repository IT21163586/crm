export class CreateCrprototypeDto {}
