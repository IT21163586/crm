export class CreateGetCrDto {}
