/* eslint-disable prettier/prettier */

export default () => ({
  email: {
    host: 'smtp.googlemail.com',
    port: 465,
    secure: true,
    auth: {
      user: 'focus.cblgroup@cbllk.com',
      pass: 'khcfwkgsnaumfmqz',
    },
  },
});
  