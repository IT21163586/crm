/* eslint-disable prettier/prettier */


export class CreateChngerequestDto {

}



