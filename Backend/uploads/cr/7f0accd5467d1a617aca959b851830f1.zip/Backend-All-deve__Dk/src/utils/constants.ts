/* eslint-disable prettier/prettier */
export const Constants = {
    ROLES : {
        Admin: 'Admin',
        Developer: 'Developer',
        SFA_User: 'SFA_User',
        HOD: 'HOD',

    },
}